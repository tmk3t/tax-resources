/***********************************************************
*修正履歴：
*         新規作成(D17GK203)      宮永　和幸
*                                 2018/07/23       001/000
*
***********************************************************/

#ifndef CLISurface_h
#define CLISurface_h

@interface CLISurface : NSObject

@property (nonatomic) NSString* Name;
@property (nonatomic) NSString* Address;
@property (nonatomic) NSString* DateOfBirth;
@property (nonatomic) NSString* Gender;

-(NSString*) LoadInformation: (NSString*)password errCode:(NSString**)errCode errDetail:(NSString**)errDetail;

@end

#endif /* CLISurface_h */
