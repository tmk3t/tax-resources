/***********************************************************
 *修正履歴：
 * 　　　　新規作成(D17GK203)　　　福井 俊輔
 * 　　　　　　　　　　　　　　　　2018/08/01　　　 001/000
 *
 ***********************************************************/
#ifndef CLICertificateInfo_h
#define CLICertificateInfo_h

@interface CLICertificateInfo : NSObject{
    NSMutableArray* IssuerRDN;
    NSMutableArray* SubjectRDN;
    NSMutableArray* IssuerAltNameRDN;
    NSMutableArray* SubjectAltNameRDN;
}

@property (nonatomic) NSString* SerialNumber;
@property (nonatomic) NSString* Issuer;
@property (nonatomic) NSString* Subject;
@property (nonatomic) NSString* IssuerAltName;
@property (nonatomic) NSString* SubjectAltName;
@property (nonatomic) NSString* NotBeforeDate;
@property (nonatomic) NSString* NotAfterDate;

-(long) GetIssuerRDNCount;
-(NSString*) GetIssuerRDN: (long) position;
-(void) SetIssuerRDN: (NSMutableArray*) aryVal;
-(long) GetSubjectRDNCount;
-(NSString*) GetSubjectRDN: (long) position;
-(void) SetSubjectRDN: (NSMutableArray*) aryVal;
-(long) GetIssuerAltNameRDNCount;
-(NSString*) GetIssuerAltNameRDN: (long) position;
-(void) SetIssuerAltNameRDN: (NSMutableArray*) aryVal;
-(long) GetSubjectAltNameRDNCount;
-(NSString*) GetSubjectAltNameRDN: (long) position;
-(void) SetSubjectAltNameRDN: (NSMutableArray*) aryVal;

@end

#endif /* CLICertificateInfo_h */
