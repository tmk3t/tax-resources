/***********************************************************
 *修正履歴：
 * 　　　　新規作成(D17GK203)　　　福井 俊輔
 * 　　　　　　　　　　　　　　　　2018/07/29　　　 001/000
 * 　　　　D18HO210　　　        福井 俊輔
 * 　　　　　　　　　　　　　　　　2019/08/13　　　 002/000
 * 　　　　D20CR201　　　        福井 俊輔
 * 　　　　　　　　　　　　　　　　2021/03/31　　　 003/000
 *
 ***********************************************************/

#ifndef CLSignerSamp_hpp
#define CLSignerSamp_hpp

#include <xmlsec/xmldsig.h>

#include <stdio.h>
#include <string>
#include "CLCertificateBase.h"
#include "CLCertificateInfo.h"

//D18HO210 2019/08/28 追加開始
#define ERR_ATTINF 0x01
#define ERR_SYSTEMINF 0x02
#define ERR_SIGNDATE 0x03
#define ERR_SENDDATE 0x04
#define ERR_RPTINF 0x05
#define ERR_NOUZEIDATE 0x06
//D18HO210 2019/08/28 追加終了 

/**
 * CLCSignature  クラス
 */
class CLCSignature
{
public:
   /**
    * CLCSignature コンストラクタ
    */
    CLCSignature(const std::string &szOpenSSLCnfPath);
    /**
     * CLCSignature デストラクタ
     */
    ~CLCSignature();
    /**
     * initLibrary 初期化
     * @param  strCnfPath CNFファイルパス
     * @return S_OK(成功）　E_FAIL（失敗）
     */
    int initLibrary(std::string strCnfPath);
    /**
     * termLibrary 後処理
     */
    void termLibrary();
    /**
     * SetCertificateP12 XML署名に使用する証明書ファイルを指定する
     * @param  szP12FilePath [I}PKCS#12ファイルパス
     * @param  szPass        [I]証明書を開くパスワード
     * @param  CertInfo      [O]電子証明書情報インターフェース
     * @return               処理結果
     */
    const char* SetCertificateP12( const char* szP12FilePath, const char* szPass, CLCertificateInfo &CertInfo );
    /**
     * SetCertificateICCard XML署名に使用するICカードへの接続を行う
     * @param  pszCspName [I]CSP名
     * @param  szPin      [I]パスワード
     * @param  CertInfo   [O]電子証明書情報インターフェース
     * @return            処理結果
     */
    const char* SetCertificateICCard( const char* pszCspName, const char* szPin, CLCertificateInfo &CertInfo );
    /**
     * SignToCertificateRegistration 電子証明書登録・更新申請データにXML署名を行う
     * @param  certRegFileName       署名対象の電子証明そ登録申請XMLファイル名
     * @param  signedCertRegFileName 署名後の電子証明書登録申請XMLファイル名
     * @param  userID                XML署名の識別子（SignatureID）
     * @return                       処理結果
     */
    const char* SignToCertificateRegistration( const char* certRegFileName, const char* signedCertRegFileName, const char* userID);
    /**
     * SignToReport 申告・申請等データにXML署名を行う
     * @param  reportFileName          署名対象の申告等データXMLファイル名
     * @param  signedReportRegFileName 署名後の申告等データXMLファイル名
     * @param  userID                  XML署名の識別子（SignatureID）
     * @return                         処理結果
     */
    const char* SignToReport( const char* reportFileName, const char* signedReportRegFileName, const char* userID);

//D18HO210 2019/08/13 追加開始
    /**
     * SignToReporteLTAX 申告・申請等データにeLTAX形式XML署名を行う
     * @param  reportFileName          署名対象の申告等データXMLファイル名
     * @param  signedReportRegFileName 署名後の申告等データXMLファイル名
     * @param  userID                  XML署名の識別子（SignatureID）
     * @return                         処理結果
     */
    const char* SignToReporteLTAX( const char* reportFileName, const char* signedReportRegFileName, const char* userID);
//D18HO210 2019/08/13 追加終了

    /**
     * clearData 保管データを削除する
     * @return                         処理結果
     */
    const char* clearData();
    
private:
    CLCertificateBase *m_pCert;     // 証明書クラス
    std::string m_strSignatureId;   // SignatureID
    std::string m_strTbsNodeId;     // Sign Target Node
    FILE *m_xmlSecLogfp = NULL;     // xmlSec ログ出力用
    std::string m_strOpenSSLCnfPath; // OpenSSL CNF filepath

//D18HO210 2019/08/13 追加開始
    long m_IseLTaxSign = false;        // 地方税形式署名フラグ
    long m_IseLTAXSyntaxErrorCode;     // reserved

    std::string m_XPathFilterIntersect;// XPATH Filter Intersect
    std::string m_XPathFilterSubtract; // XPATH Filter Subtract

    /**
     * create_node Libxml2用ノード作成処理
     * @param  node_name 要素名
     * @param  id        要素ID属性
     * @param  text      要素のテキスト
     * @return           処理結果
     */
    xmlNodePtr create_node(unsigned char* node_name, unsigned char* id = NULL, unsigned char* text = NULL);
    
    /**
     * preSignForeLTAX eLTAX署名前にeLTAX独自のXML更新処理
     * @param  pDoc xmlDoc
     * @return          処理結果
     */
    bool preSignForeLTAX(xmlDocPtr pDoc);
    /**
     * xmlSecTmplTransformAddXPath2_foreLtax eLTAX用XPATH追加処理
     * @param  transformNode 要素名
     * @param  type        タイプ
     * @param  expression      XPATH式
     * @param  nsList      名前空間ペア情報
     * @return           処理結果
     */
    int xmlSecTmplTransformAddXPath2_foreLtax(xmlNodePtr transformNode, const xmlChar* type,
                                              const xmlChar *expression, const xmlChar **nsList);
    
    /**
     * SeteLTAXSignMode eLTAX署名モード設定
     * @param  bstrXPathFilterIntersect XPATHFilter Intersect
     * @param  bstrXPathFilterSubtract XPATHFilter Subtract
     * @return          処理結果
     */
    RESULT SeteLTAXSignMode(const std::string bstrXPathFilterIntersect, const std::string bstrXPathFilterSubtract);
    /**
     * CleareLTAXSignMode eLTAX署名モード解除
     * @return          処理結果
     */
    RESULT CleareLTAXSignMode();
    /**
     * get_IseLTAXSyntaxError eLTAX署名前処理でエラーを検出した場合の情報取得
     * @param  pVal エラーコード格納領域
     * @return          処理結果
     */
    RESULT get_IseLTAXSyntaxError(long *pVal);

    
    std::string m_strSignAddNodeId;       // SignAddNodeId
    std::string m_strSignAddNodeNamespace;// SignAddNodeNamespace

//D18HO210 2019/08/13 追加終了

    /**
     * signToXml 指定されたXMLファイルにSetCertificateした証明書で署名付与を行う
     * @param  xmlFile     署名対象のXMLファイル名
     * @param  signXmlFile 署名後のXMLファイル名
     * @param  userID      XML署名の識別子（SigntureID）
     * @return             処理結果 (S_OK)
     */
    RESULT signToXml( const char* xmlFile, const char* signXmlFile, const char* userID);
    /**
     * addTimeToSignatureId XML署名の識別子に追加するタイムスタンプを生成する
     * @return 処理結果
     */
    bool addTimeToSignatureId();
    /**
     * cashDefaultTbsNodeId 署名対象要素の取得
     * @param  pDoc 対象のXMLDoc
     * @return      署名対象要素のID属性値
     */
    std::string cashDefaultTbsNodeId(xmlDocPtr pDoc);

    int cryptoEngineInitialize();
    int xmlEngineInitialize();
    int xmlEngineTerminate();
    int cryptEngineTerminate();

//D20CR201 2021/03/31 追加開始
    /**
     * AddEnvelopedTransform Enveloped形式署名フラグ設定
     * @return             処理結果 (S_OK)
     */
    RESULT AddEnvelopedTransform();

    bool m_IsEnvelopedTransformAdded = false;   // Enveloped形式署名フラグ
//D20CR201 2021/03/31 追加終了

};

#endif /* CLSignerSamp_hpp */
