/***********************************************************
 *修正履歴：
 * 　　　　新規作成(D17GK203)　　　福井 俊輔
 * 　　　　　　　　　　　　　　　　2018/08/01　　　 001/000
 * 　　　　D18HO210　　　        福井 俊輔
 * 　　　　　　　　　　　　　　　　2019/08/13　　　 002/000
 *
 ***********************************************************/

#ifndef CLISignature_h
#define CLISignature_h

#import "CLICertificateInfo.h"

@interface CLISignature : NSObject

/**
 * SetCertificateP12関数
 * @param pkcs12File PKCS#12ファイルパス
 * @param password 証明書ファイルを開くパスワード
 * @param ppCertInfo 電子証明書情報インターフェースを受け取る変数へのポインタ
 * @return 処理結果（S_OK,ERROR_FILE_NOT_FOUND,CRYPT_E_NO_MATCH,ERROR_INVALID_PASSWORD,E_FAIL)
 */
-(NSString*)SetCertificateP12: (NSString*) pkcs12File pass:(NSString*) password info:(CLICertificateInfo**) ppCertInfo;
/**
 * SetCertificateICCard関数
 * @param cspName ICカード発行元名称
 * @param password ICカードのパスワード
 * @param ppCertInfo 電子証明書情報インターフェースを受け取る変数へのポインタ
 * @return 処理結果（S_OK,EACCESSDENIED,CRYPT_E_NO_MATCH,ERROR_INVALID_PASSWORD,E_CARDLOCK,E_FAIL)
 */
-(NSString*)SetCertificateICCard: (NSString*) cspName pass:(NSString*) password info:(CLICertificateInfo**) ppCertInfo;
/**
 * SignToCertificateRegistration関数
 * @param certRegFileName 署名対象の電子証明書登録申請XMLファイル名
 * @param signedCertRegFileName 署名後の電子証明書登録申請XMLファイル名
 * @param userID XML署名の識別子（SingnatureId）
 * @return 処理結果（S_OK,E_INVALID,E_FAIL)
 */
-(NSString*)SignToCertificateRegistration: (NSString*) certRegFileName signedFile:(NSString*) signedCertRegFileName id:(NSString*) userID;
/**
 * SignToReport関数
 * @param reportFileName 署名対象の申告等データXMLファイル名
 * @param signedReportRegFileName 署名後の申告等データXMLファイル名
 * @param userID XML署名の識別子（SingnatureId）
 * @return 処理結果（S_OK,E_INVALID,E_FAIL)
 */
-(NSString*)SignToReport: (NSString*) reportFileName signedFile:(NSString*) signedReportRegFileName id:(NSString*) userID;
//D18HO210 2019/08/13 追加開始
/**
 * SignToReportEltax関数
 * @param reportFileName 署名対象の申告等データXMLファイル名
 * @param signedReportRegFileName 署名後の申告等データXMLファイル名
 * @param userID XML署名の識別子（SingnatureId）
 * @return 処理結果（S_OK,E_INVALID,E_FAIL)
 */
-(NSString*)SignToReportEltax: (NSString*) reportFileName signedFile:(NSString*) signedReportRegFileName id:(NSString*) userID;
//D18HO210 2019/08/13 追加終了
/**
 * clearData関数
 * @param なし
 * @return 処理結果（S_OK,E_FAIL)
 */
-(NSString*)clearData;

@end

#endif /* CLISignature_h */
