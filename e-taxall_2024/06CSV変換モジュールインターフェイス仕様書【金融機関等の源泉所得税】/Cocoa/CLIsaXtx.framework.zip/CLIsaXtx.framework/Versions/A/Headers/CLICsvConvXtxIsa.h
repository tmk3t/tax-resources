/***********************************************************
 *修正履歴：
 *         新規作成                野元  康二郎
 *                                 2018/06/01       001/000
 *
 *         D22GE201                青山  海渡
 *                                 2023/05/17       002/000
 *
 *         D23GE003                青山  海渡
 *                                 2024/03/06       003/000
 *
 ***********************************************************/
#ifndef CLICsvConvXtxIsa_h
#define CLICsvConvXtxIsa_h

#import "CLIConvertResultIsa.h"

/**
 CLICsvConvXtxIsa
  NISAに係る手続用CSVファイルの検証、申告等データを作成するためのインターフェース
 */
@interface CLICsvConvXtxIsa : NSObject

/* CsvCheck */
-(CLIConvertResultIsa*)CsvCheck:(NSString*)csvPathName;

/* CsvConvXtx */
-(CLIConvertResultIsa*)CsvConvXtx:(NSString*)csvPathName
 Param01:(NSString*)xtxPathName
 Param02:(NSString*)zeimushoCD
 Param03:(NSString*)nozeishaId
 Param04:(NSString*)kojinBango
 Param05:(NSString*)hojinBango
 Param06:(NSString*)nozeishaNm
 Param07:(NSString*)nozeishaAdr
 Param08:(NSString*)daihyoNm
 Param09:(NSString*)dairiId
 Param10:(NSString*)dairiNm
 Param11:(NSString*)dairiAdr
 Param12:(NSString*)tetsuzuki
 Param13:(NSString*)softName;

/* ELCsvCheck */
-(CLIConvertResultIsa*)ELCsvCheck:(NSString*)csvPathName
 Param01:(long)csvDistKey;

/* ELCsvConvXtx */
-(CLIConvertResultIsa*)ELCsvConvXtx:(long)csvDistKey
 Param01:(NSString*)zeimushoCD
 Param02:(NSString*)nozeishaId
 Param03:(NSString*)kojinBango
 Param04:(NSString*)hojinBango
 Param05:(NSString*)nozeishaNm
 Param06:(NSString*)nozeishaAdr
 Param07:(NSString*)daihyoNm
 Param08:(NSString*)dairiId
 Param09:(NSString*)dairiNm
 Param10:(NSString*)dairiAdr
 Param11:(NSString*)tetsuzuki;

/* CsvWrite */
-(CLIConvertResultIsa*)CsvWrite:(NSString*)csvPath
 Param01:(NSString*)csvData;

/* Terminate */
-(void)Terminate;

// D22GE201 2023/05/17 追加開始
/* CsvCheckFinance */
-(CLIConvertResultIsa*)CsvCheckFinance:(NSString*)csvPathName;

/* CsvConvXtxFinance */
-(CLIConvertResultIsa*)CsvConvXtxFinance:(NSString*)csvPathName
 xtxPathName:(NSString*)xtxPathName
 zeimushoCD:(NSString*)zeimushoCD
 nozeishaId:(NSString*)nozeishaId
 kojinBango:(NSString*)kojinBango
 hojinBango:(NSString*)hojinBango
 nozeishaNm:(NSString*)nozeishaNm
 nozeishaAdr:(NSString*)nozeishaAdr
 daihyoNm:(NSString*)daihyoNm
 dairiId:(NSString*)dairiId
 dairiNm:(NSString*)dairiNm
 dairiAdr:(NSString*)dairiAdr
 tetsuzuki:(NSString*)tetsuzuki
 teishutsuEra:(NSString*)teishutsuEra
 teishutsuYear:(NSString*)teishutsuYear
 teishutsuMonth:(NSString*)teishutsuMonth
 teishutsuDay:(NSString*)teishutsuDay
 softName:(NSString*)softName
 nozeishaZip1:(NSString*)nozeishaZip1
 nozeishaZip2:(NSString*)nozeishaZip2;

/* ELCsvCheckFinance */
-(CLIConvertResultIsa*)ELCsvCheckFinance:(NSString*)csvPathName
 csvDistKey:(long)csvDistKey;

/* ELCsvConvXtxFinance */
-(CLIConvertResultIsa*)ELCsvConvXtxFinance:(long)csvDistKey
 zeimushoCD:(NSString*)zeimushoCD
 nozeishaId:(NSString*)nozeishaId
 kojinBango:(NSString*)kojinBango
 hojinBango:(NSString*)hojinBango
 nozeishaNm:(NSString*)nozeishaNm
 nozeishaAdr:(NSString*)nozeishaAdr
 daihyoNm:(NSString*)daihyoNm
 dairiId:(NSString*)dairiId
 dairiNm:(NSString*)dairiNm
 dairiAdr:(NSString*)dairiAdr
 tetsuzuki:(NSString*)tetsuzuki
 teishutsuEra:(NSString*)teishutsuEra
 teishutsuYear:(NSString*)teishutsuYear
 teishutsuMonth:(NSString*)teishutsuMonth
 teishutsuDay:(NSString*)teishutsuDay
 softName:(NSString*)softName
 nozeishaZip1:(NSString*)nozeishaZip1
 nozeishaZip2:(NSString*)nozeishaZip2;
// D22GE201 2023/05/17 追加終了
// D23GE003 2024/03/04 追加開始
/* CsvCheckCrossBorder */
-(CLIConvertResultIsa*)CsvCheckCrossBorder:(NSString*)csvPathName;

/* CsvConvXtxCrossBorder */
-(CLIConvertResultIsa*)CsvConvXtxCrossBorder:(NSString*)csvPathName
 xtxPathName:(NSString*)xtxPathName
 zeimushoCD:(NSString*)zeimushoCD
 teishutsuEra:(NSString*)teishutsuEra
 teishutsuYear:(NSString*)teishutsuYear
 teishutsuMonth:(NSString*)teishutsuMonth
 teishutsuDay:(NSString*)teishutsuDay
 nozeishaId:(NSString*)nozeishaId
 kojinBango:(NSString*)kojinBango
 hojinBango:(NSString*)hojinBango
 nozeishaNm:(NSString*)nozeishaNm
 nozeishaZip1:(NSString*)nozeishaZip1
 nozeishaZip2:(NSString*)nozeishaZip2
 nozeishaAdr:(NSString*)nozeishaAdr
 daihyoNm:(NSString*)daihyoNm
 dairiId:(NSString*)dairiId
 dairiNm:(NSString*)dairiNm
 dairiAdr:(NSString*)dairiAdr
 tetsuzuki:(NSString*)tetsuzuki
 softName:(NSString*)softName;
 
/* ELCsvCheckCrossBorder */
-(CLIConvertResultIsa*)ELCsvCheckCrossBorder:(NSString*)csvPathName
 csvDistKey:(long)csvDistKey;
 
/* ELCsvConvXtxCrossBorder */
-(CLIConvertResultIsa*)ELCsvConvXtxCrossBorder:(long)csvDistKey
 zeimushoCD:(NSString*)zeimushoCD
 teishutsuEra:(NSString*)teishutsuEra
 teishutsuYear:(NSString*)teishutsuYear
 teishutsuMonth:(NSString*)teishutsuMonth
 teishutsuDay:(NSString*)teishutsuDay
 nozeishaId:(NSString*)nozeishaId
 kojinBango:(NSString*)kojinBango
 hojinBango:(NSString*)hojinBango
 nozeishaNm:(NSString*)nozeishaNm
 nozeishaZip1:(NSString*)nozeishaZip1
 nozeishaZip2:(NSString*)nozeishaZip2
 nozeishaAdr:(NSString*)nozeishaAdr
 daihyoNm:(NSString*)daihyoNm
 dairiId:(NSString*)dairiId
 dairiNm:(NSString*)dairiNm
 dairiAdr:(NSString*)dairiAdr
 tetsuzuki:(NSString*)tetsuzuki
 softName:(NSString*)softName;
// D23GE003 2024/03/04 追加終了

@end

#endif /* CLICsvConvXtxIsa_h */
