/***********************************************************
 *修正履歴：
 *         新規作成                野元  康二郎
 *                                 2018/06/01       001/000
 *
 ***********************************************************/
#ifndef CLIConvertResultIsa_h
#define CLIConvertResultIsa_h

#import <Foundation/Foundation.h>

/**
 CLIConvertResultIsa
 CLICsvConvXtxIsaインターフェースの処理結果を取得するインターフェース
 */
@interface CLIConvertResultIsa : NSObject


/**
 Result
 処理結果プロパティ
 */
@property (nonatomic, copy) NSString* Result;
/**
 DetailErrorInfo
 詳細エラー情報プロパティ
 */
@property (nonatomic, copy) NSString* DetailErrorInfo;
/**
 RecordCount
 レコード数プロパティ
 */
@property (nonatomic, copy) NSString* RecordCount;
/**
 ProcId
 手続きIDプロパティ
 */
@property (nonatomic, copy) NSString* ProcId;
/**
 XtxData
 変換後のXTXデータプロパティ
 */
@property (nonatomic, copy) NSString* XtxData;


/* initialize */
-(void)initialize;

@end

#endif /* CLIConvertResultIsa_h */
