/***********************************************************
 *修正履歴：
 *         新規作成                野元  康二郎
 *                                 2018/06/01       001/000
 *
 ***********************************************************/
#import <Cocoa/Cocoa.h>

//! Project version number for CLIsaXtx.
FOUNDATION_EXPORT double CLIsaXtxVersionNumber;

//! Project version string for CLIsaXtx.
FOUNDATION_EXPORT const unsigned char CLIsaXtxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CLIsaXtx/PublicHeader.h>


