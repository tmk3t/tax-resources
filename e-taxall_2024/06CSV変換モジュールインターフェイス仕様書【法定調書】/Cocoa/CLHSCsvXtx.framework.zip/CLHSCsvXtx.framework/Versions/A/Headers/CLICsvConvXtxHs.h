/***********************************************************
*修正履歴：
*         新規作成                本望  誠
*                                 2018/06/01       001/000
*
*         D20HS003                黒川  和輝
*                                 2020/07/17       002/000
*
***********************************************************/
#ifndef CLICsvConvDataCbC_h
#define CLICsvConvDataCbC_h

#import <Foundation/Foundation.h>
#import "CLIConvertResultHs.h"

/**
 CLICsvConvXtxHs インターフェイスクラス
 */
@interface CLICsvConvXtxHs : NSObject

 //HSCsvCheck関数
-(CLIConvertResultHs*) HSCsvCheck: (NSString*) csvPathName
 distKey: (long) csvDistKey
 teishutsuKbn: (NSString*) teishutsuKbn
 nenbun: (NSString*) nenbun
 loadedNumber: (long) loadedNumber
 shikibetsuCD: (NSString*) shikibetsuCD
 kyoutuuID: (NSString*) kyoutuuID
 bundle: (NSString*) bundle;

 //HSCsvConvXtx関数
-(CLIConvertResultHs*) HSCsvConvXtx:(NSString*) iTData
 nouzeishaNM: (NSString*) nouzeishaNM
 gokeiData: (NSString*) gokeiData
 tenpuData: (NSString*) tenpuData
 softNM: (NSString*) softNM
 bundle: (NSString*) bundle;

 //HSCsvClear関数
-(CLIConvertResultHs*) HSCsvClear: (NSString*) skbtCd;

 //HSCsvWrite関数
-(CLIConvertResultHs*) HSCsvWrite: (NSString*) csvPath csvData: (NSString*) csvData;
//Terminate関数
-(void) Terminate;

//D20HS003 2020/07/17 追加開始
 //HSCsvCheck2関数
-(CLIConvertResultHs*) HSCsvCheck2: (NSString*) csvPathName
 distKey: (long) csvDistKey
 teishutsuKbn: (NSString*) teishutsuKbn
 nenbun: (NSString*) nenbun
 nengetsu: (NSString*) nengetsu
 keisanFrom: (NSString*) keisanFrom
 keisanTo: (NSString*) keisanTo
 loadedNumber: (long) loadedNumber
 shikibetsuCD: (NSString*) shikibetsuCD
 kyoutuuID: (NSString*) kyoutuuID
 bundle: (NSString*) bundle;

 //HSCsvConvXtx2関数
-(CLIConvertResultHs*) HSCsvConvXtx2:(NSString*) iTData
 nouzeishaNM: (NSString*) nouzeishaNM
 gokeiData: (NSString*) gokeiData
 tenpuData: (NSString*) tenpuData
 softNM: (NSString*) softNM
 bundle: (NSString*) bundle;

 //HSCsvConvXml関数
-(CLIConvertResultHs*) HSCsvConvXml:(NSString*) csvPathName
 teishutsuKbn: (NSString*) teishutsuKbn
 nenbun: (NSString*) nenbun
 nengetsu: (NSString*) nengetsu
 keisanFrom: (NSString*) keisanFrom
 keisanTo: (NSString*) keisanTo
 shikibetsuCD: (NSString*) shikibetsuCD
 kyoutuuID: (NSString*) kyoutuuID
 softNM: (NSString*) softNM
 bundle: (NSString*) bundle
 nouzeishaNM: (NSString*) nouzeishaNM;
//D20HS003 2020/07/17 追加終了

@end
#endif /* CLICsvConvDataCbC_h */
