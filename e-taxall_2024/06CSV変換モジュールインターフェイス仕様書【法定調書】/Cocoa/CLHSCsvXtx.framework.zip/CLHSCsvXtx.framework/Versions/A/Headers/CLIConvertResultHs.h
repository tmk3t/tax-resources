/***********************************************************
*修正履歴：
*         新規作成                本望  誠
*                                 2018/06/01       001/000
*
*         D20HS003                黒川  和輝
*                                 2020/07/17       002/000
*
***********************************************************/
#ifndef CLIConvertResultHs_h
#define CLIConvertResultHs_h

#import <Foundation/Foundation.h>


/**
 CLIConvertResultHs インターフェイスクラス
 */
@interface CLIConvertResultHs : NSObject

/** 
 Result プロパティ
 処理結果 「S_OK」（正常終了）、または、「E_FAIL」（異常終了）、「W_OK」（警告あり）を取得する。
 */
@property (nonatomic, copy) NSString* Result;

/**
 DetailErrorInfo プロパティ
 詳細エラー情報 エラー発生時の詳細な情報を取得する。
 */
@property (nonatomic, copy) NSString* DetailErrorInfo;

/**
 RecordCount プロパティ
 レコード数 レコード数を取得する。
 */
@property (nonatomic, copy) NSString* RecordCount;

/**
 ProcId プロパティ
 手続きID 手続きIDを取得する。
 */
@property (nonatomic, copy) NSString* ProcId;

/**
 XtxData プロパティ
 XTXデータ 変換後のXTXデータを取得する。
 */
@property (nonatomic, copy) NSString* XtxData;

//D20HS003 2020/07/17 追加開始
/**
 XmlData プロパティ
 XMLデータ 変換後のXMLデータを取得する。
 */
@property (nonatomic, copy) NSString* XmlData;

//D20HS003 2020/07/17 追加終了

/**
 ReportId プロパティ
 様式ID 様式IDを取得する。
 */
@property (nonatomic, copy) NSString* ReportId;

/**
 SumTotal1 プロパティ
 合計値1 合計値1を取得する。
 */
@property (nonatomic, copy) NSString* SumTotal1;

/**
 SumTotal2 プロパティ
 合計値2 合計値2を取得する。
 */
@property (nonatomic, copy) NSString* SumTotal2;


@end
#endif /* CLIConvertResultHs_h */
